from pylab import *
from numpy import *
from numpy.linalg import norm
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib
np.set_printoptions(threshold=np.inf)

def f(x, y, theta):
    #x = vstack( (ones((1, x.shape[0])), x))
    print x
    return sum( (y - dot(x,theta)) ** 2)


def df(x, y, theta):
    #x = vstack( (ones((1, x.shape[0])), x))
    #print x.shape
    #print theta.shape
    #print dot(x,theta)
    return -2*sum(x.T*(y-dot(x,theta)), 1)


def grad_descent(f, df, x, y, init_t, alpha):
    EPS = 1e-6   #EPS = 10**(-5)
    prev_t = init_t-10*EPS
    t = init_t.copy()
    max_iter = 60000
    iter  = 0
    while norm(t - prev_t) >  EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t)
        #if iter % 1000 == 0:
            #print "Iter", iter
            #print " f(x) = %.2f" % ( f(x, y, t)) 
            #print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    print iter
    return t


def classifygender(alpha,n):
    names = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    for i in range (len(names)):
        names[i] = names[i].split()[1].lower()

    y = []
    x = []
    theta0 = zeros(32*32+1)
    
    if n != -1:
        print n
        for name in names:
            k = 0
            for files in os.listdir(address+ name+'/learnset'):
                if files != '.DS_Store':
                    if k < n:
                        yy = 0
                        t = [1]
                        #print (address+ name+'/learnset'+ '/'+files)
                        im = imread(address+ name+'/learnset'+ '/'+files)
                        im.astype(float) 
                        im = im/255.0
                        #print im
                        if files.find('baldwin') != -1 or files.find('carell') != -1 or files.find('hader') != -1:
                            yy = 1
                        for i in range (32):
                            for j in range (32):
                                t.append(im[i][j])
                        #print len(t)
                        x.append(t)
                        y.append(yy)
                        #print files
                        k += 1
                        #print k
            #ys = asarray(y) 
    else:
        for name in names:
            for files in os.listdir(address+ name+'/learnset'):
                if files != '.DS_Store':
                    yy = 0
                    t = [1]
                    #print (address+ name+'/learnset'+ '/'+files)
                    im = imread(address+ name+'/learnset'+ '/'+files)
                    im.astype(float) 
                    im = im/255.0
                    #print im
                    if files.find('baldwin') != -1 or files.find('carell') != -1 or files.find('hader') != -1:
                        yy = 1
                    for i in range (32):
                        for j in range (32):
                            t.append(im[i][j])
                    #print len(t)
                    x.append(t)
                    y.append(yy)
    x = asarray(x)
    y= asarray(y)
    #print 'now array'
    #print x.shape
    #print y
    #print theta0.shape
    theta = grad_descent(f, df, x, y, theta0, alpha)
    return theta




def Ntestcase(theta,names):
    results =[]
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    for name in names:
        for files in os.listdir(address+ 'Fine'):
            if files != '.DS_Store':
                if files.find(name) != -1:
                    im = imread(address+'Fine/'+files)
                    #print im
                    l = [1]
                    for i in range (32):
                        for j in range (32):
                            l.append(im[i][j]/255.0)
                    x = asarray(l)
                    #print x.shape
                    result = dot(x,theta)
                    results.append(name)
                    results.append(float(result))
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[3] or results[2*i] == names[4] or results[2*i] == names[5]:
            if results[2*i+1] <= 0.5:
                correct += 1
        else:
            if results[2*i+1] > 0.5:
                correct += 1
    #print correct
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The accuracy of non6 is ', percentage
    return percentage

def validcase(theta,names):
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    results =[]
    for name in names:
        for files in os.listdir(address+ name+'/validset'):
            im = imread(address+ name+'/validset'+ '/'+files)
            #print im
            l = [1]
            for i in range (32):
                for j in range (32):
                    l.append(im[i][j]/255.0)
            x = asarray(l)
            #print x
            result = dot(x,theta)
            results.append(name)
            results.append(float(result))
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[3] or results[2*i] == names[4] or results[2*i] == names[5]:
            if results[2*i+1] >= 0.5:
                correct += 1
        else:
            if results[2*i+1] < 0.5:
                correct += 1
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The accuracy for validation set is ',percentage
    return percentage


def learncase(theta,names,n):
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    results =[]
    if n != -1:
        for name in names:
            k = 0
            for files in os.listdir(address+ name+'/learnset'):
                if k < n:
                    im = imread(address+ name+'/learnset'+ '/'+files)
                    #print im
                    l = [1]
                    for i in range (32):
                        for j in range (32):
                            l.append(im[i][j]/255.0)
                    x = asarray(l)
                    #print x
                    result = dot(x,theta)
                    results.append(name)
                    results.append(float(result))
                    k += 1
    else:
        for name in names:
            for files in os.listdir(address+ name+'/learnset'):
                im = imread(address+ name+'/learnset'+ '/'+files)
                #print im
                l = [1]
                for i in range (32):
                    for j in range (32):
                        l.append(im[i][j]/255.0)
                x = asarray(l)
                #print x
                result = dot(x,theta)
                results.append(name)
                results.append(float(result))
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[3] or results[2*i] == names[4] or results[2*i] == names[5]:
            if results[2*i+1] >= 0.5:
                correct += 1
        else:
            if results[2*i+1] < 0.5:
                correct += 1
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The accuracy for learning set is ',percentage
    return percentage



if __name__ == '__main__':
    Tnames = ['Daniel Radcliffe', 'Gerard Butler', 'Michael Vartan', 'Kristin Chenoweth', 'Fran Drescher', 'America Ferrera']
    for i in range (len(Tnames)):
        Tnames[i] = Tnames[i].split()[1].lower()
        
    names = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']
    for i in range (len(names)):
        names[i] = names[i].split()[1].lower()
        
    accuracy1 = []
    accuracy2 = []
    theta0 = classifygender(0.000001, 10)
    per01 = testcase(theta0,Tnames)
    per02 = learncase(theta0,names,10)
    accuracy1.append(per01)
    accuracy2.append(per02)
    theta1 = classifygender(0.000001, 20)
    per11 = testcase(theta1,Tnames)
    per12 = learncase(theta1,names,20)
    accuracy1.append(per11)
    accuracy2.append(per12)    
    theta2 = classifygender(0.000001, 30)
    per21 = testcase(theta2,Tnames)
    per22 = learncase(theta2,names,30)
    accuracy1.append(per21)
    accuracy2.append(per22)    
    theta3 = classifygender(0.000001, 40)
    per31 = testcase(theta3,Tnames)
    per32 = learncase(theta3,names,40)
    accuracy1.append(per31)
    accuracy2.append(per32)    
    theta4 = classifygender(0.000001, 50)
    per41 = testcase(theta4,Tnames)
    per42 = learncase(theta4,names,50)    
    accuracy1.append(per41)
    accuracy2.append(per42)    
    theta5 = classifygender(0.000001, 60)
    per51 = testcase(theta5,Tnames)
    per52 = learncase(theta5,names,60)
    accuracy1.append(per51)
    accuracy2.append(per52)    
    theta6 = classifygender(0.000001, -1)
    per61 = testcase(theta6,Tnames)
    per62 = learncase(theta6,names,-1)
    accuracy1.append(per61)
    accuracy2.append(per62)    
    
    num = [10,20,30,40,50,60,70]
    print accuracy1
    print accuracy2
    line1, = plt.plot(num,accuracy1, marker='o', label='Accuracy 1')
    line2, = plt.plot(num,accuracy2, marker='o', label='Accuracy 2')



    plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
    plt.xlabel('Number of pictures learned')
    plt.ylabel('Accuracy')
    plt.title('Performance of the classifier on learning set and validation set with different number of pictures learned')
    plt.show()
    