from pylab import *
from numpy import *
from numpy.linalg import norm
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib
np.set_printoptions(threshold=np.inf)

def f(x, y, theta):
    #x = vstack( (ones((1, x.shape[0])), x))
    #print x
    return sum( (y - dot(x,theta)) ** 2)


def df(x, y, theta):
    #x = vstack( (ones((1, x.shape[0])), x))
    #print x.shape
    #print theta.shape
    #print dot(x,theta)
    return -2*sum(x.T*(y-dot(x,theta)), 1)


def grad_descent(f, df, x, y, init_t, alpha,max_iter):
    EPS = 1e-6   #EPS = 10**(-5)
    prev_t = init_t-10*EPS
    t = init_t.copy()
    iter  = 0
    while norm(t - prev_t) >  EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t)
        #if iter % 1000 == 0:
            #print "Iter", iter
            #print " f(x) = %.2f" % ( f(x, y, t)) 
            #print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    print iter
    return t


address = os.path.dirname(os.path.realpath('__file__'))+'/'



def GradientDes(names,n,alpha,maxit):
# names is the list of 2 names that would like to be identified. By default, the first one will be assigned to a value of 1.
# n is the number of pictures in the learning set that would like to be learned. If n == -1 means all of the set
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    y = []
    x = []
    theta0 = zeros(32*32+1)
    if n == -1:
        for name in names:
            for files in os.listdir(address+ name+'/learnset'):
                if files != '.DS_Store':
                    yy = 0
                    t = [1]
                    #print (address+ name+'/learnset'+ '/'+files)
                    im = imread(address+ name+'/learnset'+ '/'+files)
                    im.astype(float) 
                    im = im/255.0
                    #print im
                    if files.find(names[0]) != -1:
                        yy = 1                      #assigning different values to different pictures according who it is
                    for i in range (32):
                        for j in range (32):
                            t.append(im[i][j])      #reading each pixel from the image
                    #print len(t)
                    x.append(t)
                    y.append(yy)

                #ys = asarray(y) 
                #print x.shape
    else:
        for name in names:
            i = 0
            for files in os.listdir(address+ name+'/learnset'):
                while i<n:
                    if files != '.DS_Store':
                        yy = 0
                        t = [1]
                        #print (address+ name+'/learnset'+ '/'+files)
                        im = imread(address+ name+'/learnset'+ '/'+files)
                        im.astype(float) 
                        im = im/255.0
                        #print im
                        if files.find(names[0]) != -1:
                            yy = 1                      #assigning different values to different pictures according who it is
                        for i in range (32):
                            for j in range (32):
                                t.append(im[i][j])      #reading each pixel from the image
                        #print len(t)
                        x.append(t)
                        y.append(yy)
                        i += 1
                        #print i
    x = asarray(x)
    y = asarray(y)
    #print 'now array'
    #print x.shape
    #print y
    #print theta0.shape
    theta = grad_descent(f, df, x, y, theta0, alpha,maxit)
    return theta

def GradientDes1(names,n,alpha,maxit):
# names is the list of 2 names that would like to be identified. By default, the first one will be assigned to a value of 1.
# n is the number of pictures in the learning set that would like to be learned. If n == -1 means all of the set
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    y = []
    x = []
    theta0 = zeros(32*32+1)
    for i in range (theta0.shape[0]):
        theta0[i] = 1
    if n == -1:
        for name in names:
            for files in os.listdir(address+ name+'/learnset'):
                if files != '.DS_Store':
                    yy = 0
                    t = [1]
                    #print (address+ name+'/learnset'+ '/'+files)
                    im = imread(address+ name+'/learnset'+ '/'+files)
                    im.astype(float) 
                    im = im/255.0
                    #print im
                    if files.find(names[0]) != -1:
                        yy = 1                      #assigning different values to different pictures according who it is
                    for i in range (32):
                        for j in range (32):
                            t.append(im[i][j])      #reading each pixel from the image
                    #print len(t)
                    x.append(t)
                    y.append(yy)

                #ys = asarray(y) 
                #print x.shape
    else:
        for name in names:
            l = 0
            for files in os.listdir(address+ name+'/learnset'):
                if l<n:
                    if files != '.DS_Store':
                        yy = 0
                        t = [1]
                        #print (address+ name+'/learnset'+ '/'+files)
                        im = imread(address+ name+'/learnset'+ '/'+files)
                        im.astype(float) 
                        im = im/255.0
                        #print im
                        if files.find(names[0]) != -1:
                            yy = 1                      #assigning different values to different pictures according who it is
                        for i in range (32):
                            for j in range (32):
                                t.append(im[i][j])      #reading each pixel from the image
                        #print len(t)
                        x.append(t)
                        y.append(yy)
                        l += 1
                        #print l
    x = asarray(x)
    y = asarray(y)
    #print 'now array'
    #print x.shape
    #print y
    #print theta0.shape
    theta = grad_descent(f, df, x, y, theta0, alpha,maxit)
    return theta

def ImTheta(theta,string):
    new = theta[1:]          #taking the coefficients of ni's
    #print new
    new = asarray(new)
    new = reshape(new,(32,32))      #form a square matrix to represent images
    #print new
    imsave(string,new)
    plt.imshow(new, interpolation='bilinear', cmap='viridis')
    plt.show()

    

def validcase(theta, names):
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    results =[]
    fmin = 10
    f = 0
    for name in names:
        for files in os.listdir(address+ name+'/validset'):
            im = imread(address+ name+'/validset'+ '/'+files)
            #print im
            y = 0
            l = [1]
            for i in range (32):
                for j in range (32):
                    l.append(im[i][j]/255.0)
            x = asarray(l)
            #print x
            result = dot(x,theta)
            if name == names[0]:
                y = 1
            f = sum( (y - dot(x,theta)) ** 2)
            if f<fmin:
                fmin = f
            results.append(name)
            results.append(float(result))
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[0]:
            if results[2*i+1] >= 0.5:
                correct += 1
        else:
            if results[2*i+1] < 0.5:
                correct += 1
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The smallest cost function value is', fmin
    print 'The accuracy for validation set is ',percentage

def traincase(theta, names):
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    results =[]
    fmin = 10
    f = 0
    for name in names:
        for files in os.listdir(address+ name+'/learnset'):
            im = imread(address+ name+'/learnset'+ '/'+files)
            #print im
            l = [1]
            y = 0
            for i in range (32):
                for j in range (32):
                    l.append(im[i][j]/255.0)
            x = asarray(l)
            #print x
            if name == names[0]:
                y = 1
            f = sum( (y - dot(x,theta)) ** 2)
            if f<fmin:
                fmin = f
            result = dot(x,theta)
            results.append(name)
            results.append(float(result))
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[0]:
            if results[2*i+1] >= 0.5:
                correct += 1
        else:
            if results[2*i+1] < 0.5:
                correct += 1
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The smallest cost function value is', fmin
    print 'The accuracy for training set is ', percentage  


if __name__ == '__main__':
    names = ['baldwin','carell']
    #theta1 = GradientDes(names,-1,0.000001,40000)
   # validcase(theta1,names)
   # traincase(theta1,names)
    #ImTheta(theta1,'fullset.jpg')
    theta2 = GradientDes(names,-1,0.000001,4000)
    ImTheta(theta2,'earlystop.jpg')
    #theta3 = GradientDes1(names,2,0.00001,1000)
    #ImTheta(theta3,'2pics.jpg')
    #theta4 = GradientDes1(names,-1,0.000001,40000)
    #ImTheta(theta4,'different_T.jpg')

    
    
    
    