
from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib




def timeout(func, args=(), kwargs={}, timeout_duration=1, default=None):
    '''From:
    http://code.activestate.com/recipes/473878-timeout-function-using-threading/'''
    import threading
    class InterruptableThread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result = None

        def run(self):
            try:
                self.result = func(*args, **kwargs)
            except:
                self.result = default

    it = InterruptableThread()
    it.start()
    it.join(timeout_duration)
    if it.isAlive():
        return False
    else:
        return it.result

    
def download(act,n):    
    newpath = os.path.dirname(os.path.realpath('__file__'))+'/Uncropped'
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    testfile = urllib.URLopener()            
    #Note: you need to create the uncropped folder first in order 
    #for this to work

    for a in act:
        name = a.split()[1].lower()
        i = 0
        if n == -1:
            for line in open("faces_subset.txt"):
                if a in line:
                    try:
                        coord = line.split()[5].split(',')
                        coordd = ','.join(str(e) for e in coord)
                        filename = coordd+'&'+name+str(i)+'.'+line.split()[4].split('.')[-1]
                        #A version without timeout (uncomment in case you need to 
                        #unsupress exceptions, which timeout() does)
                        #testfile.retrieve(line.split()[4], "uncropped/"+filename)
                        #timeout is used to stop downloading images which take too long to download
                        timeout(testfile.retrieve, (line.split()[4], "uncropped/"+filename), {}, 50)
                        if not os.path.isfile("uncropped/"+filename):
                            continue
                        print filename
                        i += 1
                    except IndexError:
                        continue
        else:
            for line in open("faces_subset.txt"):
                if a in line:
                    if i < n:
                        try:
                            coord = line.split()[5].split(',')
                            coordd = ','.join(str(e) for e in coord)
                            filename = coordd+'&'+name+str(i)+'.'+line.split()[4].split('.')[-1]
                            #A version without timeout (uncomment in case you need to 
                            #unsupress exceptions, which timeout() does)
                            #testfile.retrieve(line.split()[4], "uncropped/"+filename)
                            #timeout is used to stop downloading images which take too long to download
                            timeout(testfile.retrieve, (line.split()[4], "uncropped/"+filename), {}, 50)
                            if not os.path.isfile("uncropped/"+filename):
                                continue
                            print filename
                            i += 1
                        except IndexError:
                            continue

if __name__ == '__main__':                    
    
    act = ['Daniel Radcliffe', 'Gerard Butler', 'Michael Vartan', 'Kristin Chenoweth', 'Fran Drescher', 'America Ferrera']
    download(act, 10)