from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
from scipy.misc import imsave
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib
import shutil


def rgb2gray(rgb):
    '''Return the grayscale version of the RGB image rgb as a 2D numpy array
    whose range is 0..1
    Arguments:
    rgb -- an RGB image, represented as a numpy array of size n x m x 3. The
    range of the values is 0..255
    '''
    
    r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b

    return gray/255.0


def cropresizeGrey():
    path = os.path.dirname(os.path.realpath('__file__'))+'/Uncropped'
    newpath = os.path.dirname(os.path.realpath('__file__'))+'/Fine'
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    for filename in os.listdir(path):
        if filename == '.DS_Store' or filename == 'Cropping.py' or filename == '73,95,268,290&gilpin56.jpg':
            continue
        else:
            try:
                #print filename
                coord = filename.split('&')[0].split(',')
                newname = filename.split('&')[1]
                #print coord
                #print newname
                dir = path+'/'+filename
                im = imread(dir)
                x1 = int(coord[0])
                y1 = int(coord[1])
                x2 = int(coord[2])
                y2 = int(coord[3])
                neww = imresize(im[y1:y2,x1:x2,:],(32,32))
                new = rgb2gray(neww)
                imsave(filename, new)
                os.rename(filename,newname)
                src = os.path.dirname(os.path.realpath('__file__'))+'/'+newname
                dst = os.path.dirname(os.path.realpath('__file__'))+'/Fine/'+newname
                shutil.move(src, dst)
            except (IOError,IndexError):
                continue
    shutil.rmtree(path)
if __name__ == '__main__': 
    cropresizeGrey()


    
