from pylab import *
from numpy import *
from numpy.linalg import norm
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib
np.set_printoptions(threshold=np.inf)

def f(x, y, theta):
    #x = vstack( (ones((1, x.shape[0])), x))
    #print x
    return sum(sum( (y - dot(theta.T,x)) ** 2,0))
    
    

def df(x, y, theta):
    #x = vstack( (ones((1, x.shape[0])), x))
    #print x.shape
    #print theta.shape
    #print dot(x,theta)
    return 2*dot(x,(dot(theta.T,x)-y).T)

def finite_dif(i,j):
    random.seed(0)
    y = reshape(rand(600),(6,100))
    x = reshape(rand(102500),(1025,100))
    for i in range (100):
        x[0][i] = 1
    h = 0.000000001
    theta0 = reshape(rand(6150),(1025,6))
    dtheta = zeros((1025,6))
    dtheta[i,j] = h
    print (f(x,y,theta0+dtheta)-f(x,y,theta0))/h
    print df(x,y,theta0)[i,j]


def grad_descent(f, df, x, y, init_t, alpha,max_iter):
    EPS = 1e-6   #EPS = 10**(-5)
    prev_t = init_t-10*EPS
    t = init_t.copy()
    iter  = 0
    while norm(t - prev_t) >  EPS and iter < max_iter:
        prev_t = t.copy()
        t -= alpha*df(x, y, t)
        #if iter % 1000 == 0:
            #print "Iter", iter
            #print " f(x) = %.2f" % ( f(x, y, t)) 
            #print "Gradient: ", df(x, y, t), "\n"
        iter += 1
    print iter
    return t



def MultDes(names,n,alpha,maxit):
# names is the list of 2 names that would like to be identified. By default, the first one will be assigned to a value of 1.
# n is the number of pictures in the learning set that would like to be learned. If n == -1 means all of the set
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    y = []
    x = []
    if n == -1:
        for name in names:
            for files in os.listdir(address+ name+'/learnset'):
                if files != '.DS_Store':
                    yy = [0,0,0,0,0,1]
                    t = [1]
                    #print (address+ name+'/learnset'+ '/'+files)
                    im = imread(address+ name+'/learnset'+ '/'+files)
                    im.astype(float) 
                    im = im/255.0
                    #print im
                    if files.find(names[0]) != -1:
                        yy = [1,0,0,0,0,0]              #assigning different values to different pictures according who it is
                    if files.find(names[1]) != -1:
                        yy = [0,1,0,0,0,0]
                    if files.find(names[2]) != -1:
                        yy = [0,0,1,0,0,0]
                    if files.find(names[3]) != -1:
                        yy = [0,0,0,1,0,0]
                    if files.find(names[4]) != -1:
                        yy = [0,0,0,0,1,0]    
                    for i in range (32):
                        for j in range (32):
                            t.append(im[i][j])      #reading each pixel from the image
                    #print len(t)
                    x.append(t)
                    y.append(yy)

                #ys = asarray(y) 
                #print x.shape
    else:
        j = 0
        for name in names:
            for files in os.listdir(address+ name+'/learnset'):
                if files != '.DS_Store':
                    if j < n:
                        yy = [0,0,0,0,0,1]
                        t = [1]
                        #print (address+ name+'/learnset'+ '/'+files)
                        im = imread(address+ name+'/learnset'+ '/'+files)
                        im.astype(float) 
                        im = im/255.0
                        #print im
                        if files.find(names[0]) != -1:
                            yy = [1,0,0,0,0,0]          #assigning different values to different pictures according who it is
                        if files.find(names[1]) != -1:
                            yy = [0,1,0,0,0,0]
                        if files.find(names[2]) != -1:
                            yy = [0,0,1,0,0,0]
                        if files.find(names[3]) != -1:
                            yy = [0,0,0,1,0,0]
                        if files.find(names[4]) != -1:
                            yy = [0,0,0,0,1,0]  
                        for i in range (32):
                            for j in range (32):
                                t.append(im[i][j])      #reading each pixel from the image
                        #print len(t)
                        x.append(t)
                        y.append(yy)
                        j += 1
    x = asarray(x)
    y = asarray(y)
    x = x.T
    y = y.T
    theta0 = zeros((32*32+1,6))
    #print 'now array'
    #print x.shape
    #print y
    #print theta0.shape
    theta = grad_descent(f, df, x, y, theta0, alpha,maxit)
    return theta


def printpic(theta,name):
    new = theta[1:]*255.0          #taking the coefficients of ni's
    #print new
    new = asarray(new)
    new = reshape(new,(32,32))      #form a square matrix to represent images
    #print new
    imsave(name,new)
    #plt.imshow(new, interpolation='bilinear', cmap='viridis')
    #plt.show()

def validtest(theta,names):
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    results =[]
    for name in names:
        for files in os.listdir(address+ name+'/validset'):
            im = imread(address+ name+'/validset'+ '/'+files)
            #print im
            l = [1]
            for i in range (32):
                for j in range (32):
                    l.append(im[i][j]/255.0)
            x = asarray(l)
            #print x
            result = dot(theta.T,x).tolist()
            results.append(name)
            results.append(result)
    #print results
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[0]:
            if results[2*i+1][0] >= 0.5:
                correct += 1
        if results[2*i] == names[1]:
            if results[2*i+1][1] >= 0.5:
                correct += 1
        if results[2*i] == names[2]:
            if results[2*i+1][2] >= 0.5:
                correct += 1
        if results[2*i] == names[3]:
            if results[2*i+1][3] >= 0.5:
                correct += 1 
        if results[2*i] == names[4]:
            if results[2*i+1][4] >= 0.5:
                correct += 1
        else:
            if results[2*i+1][5] >= 0.5:
                correct += 1
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The accuracy of valid set is ',percentage    


def learntest(theta,names):
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    results =[]
    for name in names:
        for files in os.listdir(address+ name+'/learnset'):
            im = imread(address+ name+'/learnset'+ '/'+files)
            #print im
            l = [1]
            for i in range (32):
                for j in range (32):
                    l.append(im[i][j]/255.0)
            x = asarray(l)
            #print x
            result = dot(theta.T,x).tolist()
            results.append(name)
            results.append(result)
    #print results
    correct = 0
    for i in range(len(results)/2):
        if results[2*i] == names[0]:
            if results[2*i+1][0] >= 0.5:
                correct += 1
        if results[2*i] == names[1]:
            if results[2*i+1][1] >= 0.5:
                correct += 1
        if results[2*i] == names[2]:
            if results[2*i+1][2] >= 0.5:
                correct += 1
        if results[2*i] == names[3]:
            if results[2*i+1][3] >= 0.5:
                correct += 1 
        if results[2*i] == names[4]:
            if results[2*i+1][4] >= 0.5:
                correct += 1
        else:
            if results[2*i+1][5] >= 0.5:
                correct += 1
    percentage = float(correct)/(len(results)/2)
    #print results
    print 'The accuracy of learn set is ',percentage 
    
if __name__ == '__main__': 
    names = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']
    address = os.path.dirname(os.path.realpath('__file__'))+'/'
    for i in range (len(names)):
        names[i] = names[i].split()[1].lower()
    theta = MultDes(names,-1,0.000001,60000)
    #print theta
    
    
    
    
    pic1 = theta[:,0]
    pic2 = theta[:,1]
    pic3 = theta[:,2]
    pic4 = theta[:,3]
    pic5 = theta[:,4]
    pic6 = theta[:,5]

    #printpic(pic1)
    #printpic(pic2)
    #printpic(pic3)
    #printpic(pic4)
    #printpic(pic5)
    #printpic(pic6)
    learntest(theta,names)
    validtest(theta,names)

    
    #finite_dif(2,0)
    