from pylab import *
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
from scipy.misc import imsave
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib
import shutil


act =['gilpin']


def random(act):
    path = os.path.dirname(os.path.realpath('__file__'))+'/'+'Fine/'

    for name in act:
        print name
        newpath = os.path.dirname(os.path.realpath('__file__'))+'/'+name
        if not os.path.exists(newpath):
            os.makedirs(newpath)
        for filename in os.listdir(path):
            if filename.find(name) != -1:
                src = path+filename
                dst = newpath+'/'+filename
                shutil.move(src, dst)
        filelist = []
        for files in os.listdir(newpath):
            filelist.append(files)
        print filelist
        learnpath = newpath+'/learnset'
        if not os.path.exists(learnpath):
            os.makedirs(learnpath)
        np.random.seed(0)
        np.random.shuffle(filelist)
        print len(filelist)
        if len(filelist) <= 90:
            for i in range(67):
                if filelist[i] != 'learnset' and filelist[i] != '.DS_Store':
                    src = newpath+'/'+filelist[i]
                    dst = learnpath+'/'+filelist[i]
                    shutil.move(src, dst)
                    print i, filelist[i]
            print ('finish learnset'+name)
            #print filelist
            validpath = newpath+'/validset'
            if not os.path.exists(validpath):
                os.makedirs(validpath)
            for i in range(10):
                if filelist[67+i] != 'learnset' and filelist[67+i]!= 'validset' and filelist[67+i] != '.DS_Store':
                    src = newpath+'/'+filelist[67+i]
                    dst = validpath+'/'+filelist[67+i]
                    shutil.move(src, dst)
                    print i,filelist[67+i]
            print ('finish validset'+name)
            #print filelist
            testpath = newpath+'/testset'
            if not os.path.exists(testpath):
                os.makedirs(testpath)
            for i in range(10):
                if filelist[77+i] != 'learnset' and filelist[77+i]!= 'validset' and filelist[77+i] != 'testset'and filelist[77+i] != '.DS_Store':
                    src = newpath+'/'+filelist[77+i]
                    dst = testpath+'/'+filelist[77+i]
                    shutil.move(src, dst)    
                    print i,filelist[77+i]
            print name
        else:
            for i in range(70):
                if filelist[i] != 'learnset' and filelist[i] != '.DS_Store':
                    src = newpath+'/'+filelist[i]
                    dst = learnpath+'/'+filelist[i]
                    shutil.move(src, dst)
                    print i, filelist[i]
            print ('finish learnset'+name)
            #print filelist
            validpath = newpath+'/validset'
            if not os.path.exists(validpath):
                os.makedirs(validpath)
            for i in range(10):
                if filelist[70+i] != 'learnset' and filelist[70+i]!= 'validset' and filelist[70+i] != '.DS_Store':
                    src = newpath+'/'+filelist[70+i]
                    dst = validpath+'/'+filelist[70+i]
                    shutil.move(src, dst)
                    print i,filelist[70+i]
            print ('finish validset'+name)
            #print filelist
            testpath = newpath+'/testset'
            if not os.path.exists(testpath):
                os.makedirs(testpath)
            for i in range(10):
                if filelist[80+i] != 'learnset' and filelist[80+i]!= 'validset' and filelist[80+i] != 'testset'and filelist[80+i] != '.DS_Store':
                    src = newpath+'/'+filelist[80+i]
                    dst = testpath+'/'+filelist[80+i]
                    shutil.move(src, dst)    
                    print i,filelist[80+i]
            print name


