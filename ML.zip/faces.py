import Downloader
import Cropping
import Random
import Gradient
import Overfit
import Multiple
from pylab import *
from numpy import *
from numpy.linalg import norm
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
import random
import time
from scipy.misc import imread
from scipy.misc import imresize
import matplotlib.image as mpimg
import os
from scipy.ndimage import filters
import urllib
np.set_printoptions(threshold=np.inf)
from matplotlib.legend_handler import HandlerLine2D


if __name__ == '__main__':
    six = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon', 'Alec Baldwin', 'Bill Hader', 'Steve Carell']
    male = ['Alec Baldwin', 'Bill Hader', 'Steve Carell']
    female = ['Lorraine Bracco', 'Peri Gilpin', 'Angie Harmon']
    Downloader.download(six,-1)         #downloading all the pictures of 6 actors
    #Downloader.download(male,-1)
    Cropping.cropresizeGrey()           #Cropping, Resizing and greyscaling the pictures
    for i in range (len(six)):
        six[i] = six[i].split()[1].lower()
    Random.random(six)                  #Randomly forming three sets for all actors
    
    names = ['baldwin','carell']
    
    
    theta1 = Gradient.GradientDes(names,-1,0.000001,40000)
    Gradient.validcase(theta1,names)
    Gradient.traincase(theta1,names)
    Gradient.ImTheta(theta1,'fullset.jpg')
    theta2 = Gradient.GradientDes(names,-1,0.000001,4000)
    Gradient.ImTheta(theta2,'earlystop.jpg')
    theta3 = Gradient.GradientDes1(names,2,0.0000001,400000)
    Gradient.ImTheta(theta3,'2pics.jpg')
    theta4 = Gradient.GradientDes1(names,-1,0.000001,40000)
    Gradient.ImTheta(theta4,'different_T.jpg')
    
    Tnames = ['Daniel Radcliffe', 'Gerard Butler', 'Michael Vartan', 'Kristin Chenoweth', 'Fran Drescher', 'America Ferrera']
    Downloader.download(Tnames, 10)
    for i in range (len(Tnames)):
        Tnames[i] = Tnames[i].split()[1].lower()
    Cropping.cropresizeGrey()
    
    
    #thetaG = Overfit.classifygender(0.0000001)                      #Learn the whole learning sets for all 6 actors

    
    accuracy1 = []
    accuracy2 = []
    theta0 = Overfit.classifygender(0.0000001, 10)
    per01 = Overfit.validcase(theta0,six)
    per02 = Overfit.learncase(theta0,six,10)
    accuracy1.append(per01)
    accuracy2.append(per02)
    theta1 = Overfit.classifygender(0.0000001, 20)
    per11 = Overfit.validcase(theta1,six)
    per12 = Overfit.learncase(theta1,six,20)
    accuracy1.append(per11)
    accuracy2.append(per12)    
    theta2 = Overfit.classifygender(0.0000001, 30)
    per21 = Overfit.validcase(theta2,six)
    per22 = Overfit.learncase(theta2,six,30)
    accuracy1.append(per21)
    accuracy2.append(per22)    
    theta3 = Overfit.classifygender(0.0000001, 40)
    per31 = Overfit.validcase(theta3,six)
    per32 = Overfit.learncase(theta3,six,40)
    accuracy1.append(per31)
    accuracy2.append(per32)    
    theta4 = Overfit.classifygender(0.0000001, 50)
    per41 = Overfit.validcase(theta4,six)
    per42 = Overfit.learncase(theta4,six,50)    
    accuracy1.append(per41)
    accuracy2.append(per42)    
    theta5 = Overfit.classifygender(0.0000001, 60)
    per51 = Overfit.validcase(theta5,six)
    per52 = Overfit.learncase(theta5,six,60)
    accuracy1.append(per51)
    accuracy2.append(per52)    
    theta6 = Overfit.classifygender(0.0000001, -1)
    per61 = Overfit.validcase(theta6,six)
    per62 = Overfit.learncase(theta6,six,-1)
    accuracy1.append(per61)
    accuracy2.append(per62)    
    
    num = [10,20,30,40,50,60,70]
    print accuracy1
    print accuracy2
    line1, = plt.plot(num,accuracy1, marker='o', label='Validation Set')
    line2, = plt.plot(num,accuracy2, marker='o', label='Training Set')

    plt.legend(handler_map={line1: HandlerLine2D(numpoints=4)})
    plt.xlabel('Number of pictures learned')
    plt.ylabel('Accuracy')
    plt.title('Performance of the classifier on learning set and validation set with different number of pictures learned')
    plt.show()
    
    Overfit.Ntestcase(theta6,Tnames)

    #print theta
     
    thetaF = Multiple.MultDes(six,-1,0.000001,60000)
    pic1 = thetaF[:,0]
    pic2 = thetaF[:,1]
    pic3 = thetaF[:,2]
    pic4 = thetaF[:,3]
    pic5 = thetaF[:,4]
    pic6 = thetaF[:,5]

    Multiple.printpic(pic1,'Bracco8.jpg')
    Multiple.printpic(pic2,'Gilpin8.jpg')
    Multiple.printpic(pic3,'Harmon8.jpg')
    Multiple.printpic(pic4,'Baldwin8.jpg')
    Multiple.printpic(pic5,'Hader8.jpg')
    Multiple.printpic(pic6,'Carell8.jpg')
    Multiple.learntest(thetaF,six)
    Multiple.validtest(thetaF,six)
    
